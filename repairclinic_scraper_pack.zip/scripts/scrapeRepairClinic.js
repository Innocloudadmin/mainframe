
const { chromium } = require('playwright');
const fs = require('fs');

(async () => {
  const url = process.argv[2] || 'https://www.repairclinic.com/Shop-For-Parts/a5b1d1022/Model-Whirlpool-WED4815EW1-Dryer-Parts';
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  await page.goto(url, {
    waitUntil: 'networkidle',
    timeout: 60000,
  });

  const html = await page.content();
  fs.writeFileSync('/tmp/repairclinic.html', html);
  console.log("Scrape complete ✅");

  await browser.close();
})();
