
# 🛠 RepairClinic Scraper Pack (n8n + Playwright)

## 🔧 Requirements
- Node.js
- Playwright (`npm install playwright && npx playwright install`)
- n8n self-hosted
- Basic bash or shell access

## 📂 Files
- `scripts/scrapeRepairClinic.js`: Main Playwright script
- Save output to `/tmp/repairclinic.html` and parse it with n8n

## ⚡ How To Use

1. Run from terminal:
   ```bash
   node scripts/scrapeRepairClinic.js "https://www.repairclinic.com/Shop-For-Parts/..."
   ```

2. In n8n:
   - Use `Execute Command` node:
     ```bash
     node /path/to/scripts/scrapeRepairClinic.js
     ```
   - Then use `Read Binary File` node to pull `/tmp/repairclinic.html`
   - Parse using Function or HTML Extract node

## 🧙 Pro Tips
- Modify script to parse JSON in-line
- Schedule it via Cron node
- Hook with Webhook for dynamic scraping

Happy hunting 😼
